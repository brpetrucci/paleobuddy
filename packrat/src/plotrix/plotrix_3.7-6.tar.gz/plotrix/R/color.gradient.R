color.gradient<-function(reds,greens,blues,nslices=50) {
 return(color.scale(1:nslices,reds,greens,blues))
}
