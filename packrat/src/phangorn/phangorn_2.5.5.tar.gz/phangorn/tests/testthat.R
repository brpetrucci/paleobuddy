library(testthat)
suppressPackageStartupMessages(library(phangorn))

test_check("phangorn")
