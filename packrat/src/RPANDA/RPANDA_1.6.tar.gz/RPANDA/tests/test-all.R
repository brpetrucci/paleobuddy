library(testthat)
library(RPANDA)
# Comment test_check in order to not run tests with R CMD check
# test_check("RPANDA")
